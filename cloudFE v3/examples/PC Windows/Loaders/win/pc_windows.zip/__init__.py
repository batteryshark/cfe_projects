import subprocess,os,zipfile,sys,glob

def get_extensions():
	return ['.001','.zip','.7z','.rar']

def extract_file_7z(ldr_dir,inpath,outpath):

	base,extn = os.path.splitext(inpath)
	subprocess.call([os.path.join(ldr_dir,'7z.exe'),'x','-aoa','%s' % inpath,'-o%s' % outpath])
	#Remove any multi-part, too
	for fl in glob.glob("%s*" % base):
		os.remove(fl)
		print("Remove %s" % fl)
	
def extract_file(inpath,outpath):

	fh = open(inpath, 'rb')
	base,extn = os.path.splitext(inpath)
	z = zipfile.ZipFile(fh)
	for name in z.namelist():
		z.extract(name,outpath)

	fh.close()
	#Remove any multi-part, too
	for fl in glob.glob("%s*" % base):
		os.remove(fl)

	
def unpack_files(data_path,ldr_dir):
	
	for root,dirs,files in os.walk(data_path):
		
		for f in files:
			print(f)
			fl,ext = os.path.splitext(f)
			
			if(ext in get_extensions()):
				extract_file_7z(ldr_dir,f,data_path)

def run(data_path):
	ldr_dir = os.path.realpath(__file__)
	os.chdir(data_path)
	
	ldr_dir,ldr_fl = os.path.split(ldr_dir)
	if(not os.path.exists('extracted')):
		unpack_files(data_path,ldr_dir)
	g = open('extracted','wb')
	g.close()	
	
	subprocess.call(["python","run.py"])
	os.chdir(ldr_dir)
	
	
	

	
if(__name__=="__main__"):
	run(sys.argv[1])