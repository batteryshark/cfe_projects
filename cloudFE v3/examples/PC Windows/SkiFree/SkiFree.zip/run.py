import subprocess,os

if(__name__=="__main__"):
	subprocess.call(["ski32.exe"])
	
